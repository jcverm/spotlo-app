# Spotlo. Page d'accueil des liens.

## Ce que ca fait

Un lien partage ressemble maintenant a :

    https://jcverm.github.io/spotlo-app/claim?type=invite&token=ABC123

Quand quelqu'un l'ouvre :
- l'app installee s'ouvre toute seule, sur le bon partage ou la bonne invitation ;
- sinon, la personne voit une page Spotlo propre avec un bouton App Store.

## Mise en place maintenant

1. Dans le depot GitHub jcverm/spotlo-app, ajoute le dossier et le fichier :

       claim/index.html

   Il sera servi a https://jcverm.github.io/spotlo-app/claim

2. C'est tout pour la partie qui marche aujourd'hui. Teste le lien sur un telephone.

## Apres la publication sur l'App Store

Dans claim/index.html, en haut du script :
- remplace APP_STORE_URL par le vrai lien de l'app ;
- passe STORE_READY a true.

A partir de la, une personne sans l'app est redirigee automatiquement vers l'App Store.

## Universal links, plus tard, pour zero page intermediaire

Objectif : l'app s'ouvre sans meme afficher la page, meme au premier lien.
Conditions :
- l'app construite avec l'entitlement associated-domains : "applinks:jcverm.github.io" ;
- le fichier apple-app-site-association servi a la RACINE du domaine :

       https://jcverm.github.io/.well-known/apple-app-site-association

  Attention : la racine du domaine n'est pas /spotlo-app/. Il faut un depot
  GitHub nomme jcverm.github.io, ou un domaine personnalise, pour servir ce fichier.

- dans apple-app-site-association, remplace TEAMID par ton Team ID Apple.

Tant que ce n'est pas fait, la page relais fait le travail. C'est juste un cran
moins fluide, avec un court passage par la page.
